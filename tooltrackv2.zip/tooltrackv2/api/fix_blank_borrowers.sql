-- ================================================================
--  fix_blank_borrowers.sql  — run in phpMyAdmin, ONE STEP AT A TIME.
--  0) EXPORT a backup of tooltrack_db first (Export tab → Go).
--  Run this BEFORE uploading the new PHP files (they use the new columns).
-- ================================================================

-- STEP 1: columns that keep the borrower's name on every transaction
ALTER TABLE transactions ADD COLUMN borrower_name_snapshot      VARCHAR(150) NULL;
ALTER TABLE transactions ADD COLUMN borrower_id_number_snapshot VARCHAR(50)  NULL;

-- STEP 2: fill them for every transaction whose borrower still exists
UPDATE transactions t
JOIN borrowers b ON b.id = t.borrower_id
SET t.borrower_name_snapshot = b.full_name,
    t.borrower_id_number_snapshot = b.id_number
WHERE t.borrower_name_snapshot IS NULL;

-- STEP 3a: PREVIEW — recover names of deleted borrowers from the audit trail
-- (every borrow was logged as "Borrowed 2x Spoon (SP-101) for Juan Dela Cruz, due ...").
-- Check the names look right, and that no transaction appears twice.
SELECT t.id, t.txn_id, t.created_at,
       SUBSTRING_INDEX(SUBSTRING_INDEX(a.description, ') for ', -1), ', due ', 1) AS recovered_name,
       a.description
FROM transactions t
JOIN tools tl ON tl.id = t.tool_id
JOIN audit_log a ON a.action = 'borrow'
     AND a.created_at BETWEEN t.created_at AND t.created_at + INTERVAL 5 SECOND
     AND a.description LIKE CONCAT('Borrowed ', t.qty, 'x %(', tl.code, ') for %')
WHERE t.type = 'borrow' AND t.borrower_id IS NULL AND t.borrower_name_snapshot IS NULL
ORDER BY t.id;

-- STEP 3b: if the preview looks right, apply it
UPDATE transactions t
JOIN tools tl ON tl.id = t.tool_id
JOIN audit_log a ON a.action = 'borrow'
     AND a.created_at BETWEEN t.created_at AND t.created_at + INTERVAL 5 SECOND
     AND a.description LIKE CONCAT('Borrowed ', t.qty, 'x %(', tl.code, ') for %')
SET t.borrower_name_snapshot = SUBSTRING_INDEX(SUBSTRING_INDEX(a.description, ') for ', -1), ', due ', 1)
WHERE t.type = 'borrow' AND t.borrower_id IS NULL AND t.borrower_name_snapshot IS NULL;

-- STEP 4: return rows take the name from the borrow they closed
UPDATE transactions r
JOIN transactions b ON b.id = r.borrow_txn_id
SET r.borrower_name_snapshot = b.borrower_name_snapshot,
    r.borrower_id_number_snapshot = b.borrower_id_number_snapshot
WHERE r.type = 'return' AND r.borrower_name_snapshot IS NULL AND b.borrower_name_snapshot IS NOT NULL;

-- STEP 5: make it impossible to repeat. Deleting a borrower or tool that has
-- transactions will now be REFUSED (use Deactivate / Retire in the app instead).
-- (If a name below doesn't exist, check the real names with: SHOW CREATE TABLE transactions;)
ALTER TABLE transactions DROP FOREIGN KEY transactions_ibfk_1;
ALTER TABLE transactions DROP FOREIGN KEY transactions_ibfk_2;
ALTER TABLE transactions
  ADD CONSTRAINT fk_txn_tool     FOREIGN KEY (tool_id)     REFERENCES tools (id)     ON DELETE RESTRICT,
  ADD CONSTRAINT fk_txn_borrower FOREIGN KEY (borrower_id) REFERENCES borrowers (id) ON DELETE RESTRICT;

-- STEP 6: see what could NOT be recovered (older rows, or audit log cleared)
SELECT id, txn_id, type, created_at FROM transactions
WHERE borrower_name_snapshot IS NULL AND (borrower_id IS NULL) ORDER BY id;
