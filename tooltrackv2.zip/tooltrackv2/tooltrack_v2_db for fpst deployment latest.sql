-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2026 at 03:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tooltrack v2_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL COMMENT 'FK -> users.id; NULL for a failed login (no known user) or if the user was later deleted',
  `username_snapshot` varchar(100) DEFAULT NULL COMMENT 'Kept even if the user account is later deleted',
  `role_snapshot` varchar(20) DEFAULT NULL,
  `action` varchar(40) NOT NULL COMMENT 'login | login_failed | logout | borrow | return | tool_create | tool_edit | tool_retire | tool_reactivate | borrower_create | borrower_edit | borrower_deactivate | borrower_reactivate | user_create | user_delete | password_reset | password_change | replacement_request | replacement_resolved | cms_sync',
  `description` varchar(500) NOT NULL COMMENT 'Human-readable summary, e.g. "Borrowed 2x Spoon (SP-101) for Juan Dela Cruz"',
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'IPv4 or IPv6',
  `user_agent` varchar(255) DEFAULT NULL COMMENT 'Raw browser User-Agent string',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`id`, `user_id`, `username_snapshot`, `role_snapshot`, `action`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(1, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Lylle Cequina (20222637, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 17:55:13'),
(2, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Cast Iron Skillet (CI-101) for Lylle Cequina, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 17:56:39'),
(3, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Bonjor Dex (202223456, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 18:09:11'),
(4, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Edwina Casipe (20151543, Faculty)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 18:23:00'),
(5, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Gabriel Napuli (202225678, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 18:24:12'),
(6, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Jenny Orit (20258976, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 18:35:56'),
(7, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Jenny Orit, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 18:35:56'),
(8, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Frank Anthony S. Casipe (20222545, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 19:33:40'),
(9, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-15 19:34:51'),
(10, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Frank Anthony S. Casipe, due 2026-10-22', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-15 19:38:19'),
(11, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Precious Faith Ebrado (20221502, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 19:43:40'),
(12, NULL, 'precious baculanta', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1', '2026-10-15 19:46:09'),
(13, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 20:01:44'),
(14, NULL, 'precious baculanta', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1', '2026-10-15 20:17:17'),
(15, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 20:59:10'),
(16, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Precious Faith Ebrado, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 21:01:20'),
(17, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Cast Iron Skillet (CI-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 21:01:58'),
(18, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Precious Faith Ebrado — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 21:35:38'),
(19, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Frank Anthony S. Casipe — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 21:36:05'),
(20, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x wok (WO-101) for Bonjor Dex, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 22:09:53'),
(21, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 4x Wine Glass (WG-09) for Bonjor Dex, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 22:10:32'),
(22, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 4x Wine Glass (WG-09) by Bonjor Dex — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 22:11:46'),
(23, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x wok (WO-101) by Bonjor Dex — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 22:12:11'),
(24, 1, 'NIORRITOS', 'Admin', 'borrower_edit', 'Updated sections (FPST) for 1 student(s): Frank Anthony S. Casipe → 2-B', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:13:04'),
(25, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x wok (WO-101) for Precious Faith Ebrado, due 2026-10-22', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:17:25'),
(26, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Cast Iron Skillet (damaged)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:30:53'),
(27, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Cast Iron Skillet (damaged)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:31:32'),
(28, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:31:47'),
(29, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:31:50'),
(30, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-15 23:31:54'),
(31, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 00:40:12'),
(32, 1, 'NIORRITOS', 'Admin', 'tool_create', 'Added tool Baso (BA-101), qty 40, price 50', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 00:42:28'),
(33, 1, 'NIORRITOS', 'Admin', 'borrower_edit', 'Updated sections (FPST) for 1 student(s): Frank Anthony S. Casipe → 2-E', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 00:53:26'),
(34, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Jenny Orit — condition: damaged', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:09:33'),
(35, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Cast Iron Skillet (other)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:11:04'),
(36, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:11:42'),
(37, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:11:51'),
(38, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Cast Iron Skillet (damaged)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:21:20'),
(39, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 01:21:32'),
(40, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 08:20:51'),
(41, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-16 08:22:22'),
(42, NULL, 'precious baculanta', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6.1 Mobile/15E148 Safari/604.1', '2026-10-16 08:23:51'),
(43, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 16; TECNO LJ6 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/154.0.8037.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]', '2026-10-16 08:27:31'),
(44, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Baso (BA-101) for Bonjor Dex, due 2026-10-23', '::1', 'Mozilla/5.0 (Linux; Android 16; TECNO LJ6 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/154.0.8037.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]', '2026-10-16 08:29:32'),
(45, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Wine Glass (WG-09) for Edwina Casipe, due 2026-10-23', '::1', 'Mozilla/5.0 (Linux; Android 16; TECNO LJ6 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/154.0.8037.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]', '2026-10-16 08:36:03'),
(46, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Wine Glass (WG-09) by Edwina Casipe — condition: good', '::1', 'Mozilla/5.0 (Linux; Android 16; TECNO LJ6 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/154.0.8037.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]', '2026-10-16 08:36:59'),
(47, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-16 08:52:37'),
(48, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:03:36'),
(49, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Frank Anthony S. Casipe, due 2026-10-23', '::1', 'Mozilla/5.0 (Linux; Android 16; TECNO LJ6 Build/BP2A.250605.031.A3; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/154.0.8037.107 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/582.0.0.61.92;]', '2026-10-16 09:06:19'),
(50, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Cast Iron Skillet (damaged)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:16:05'),
(51, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:16:19'),
(52, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:16:22'),
(53, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Cast Iron Skillet (CI-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:20:18'),
(54, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Cast Iron Skillet (CI-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:20:59'),
(55, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Frank Anthony S. Casipe — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:22:07'),
(56, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x wok (WO-101) by Precious Faith Ebrado — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:24:31'),
(57, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Cast Iron Skillet (CI-101) by Lylle Cequina — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:25:15'),
(58, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 09:46:13'),
(59, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-16 10:02:22'),
(60, NULL, NULL, NULL, 'login_failed', 'Failed login attempt for username \'admin\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 14:28:42'),
(61, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 14:28:48'),
(62, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 29x Baso (BA-101) for Jenny Orit, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:17:47'),
(63, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 9x Baso (BA-101) by Jenny Orit — condition: damaged', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:18:59'),
(64, 1, 'NIORRITOS', 'Admin', 'tool_condition_update', 'Repaired 9x Baso (BA-101): damaged -> good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:20:39'),
(65, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36', '2026-10-18 15:46:04'),
(66, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 20x Baso (BA-101) by Jenny Orit — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:47:33'),
(67, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Baso (BA-101) by Bonjor Dex — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:48:35'),
(68, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x wok (WO-101) for Frank Anthony S. Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:49:44'),
(69, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x wok (WO-101) for Gabriel Napuli, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 15:51:46'),
(70, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 8x Baso (BA-101) for Bonjor Dex, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:04:59'),
(71, 1, 'NIORRITOS', 'Admin', 'tool_retire', 'Retired tool Baso (BA-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:12:49'),
(72, 1, 'NIORRITOS', 'Admin', 'tool_reactivate', 'Reactivated tool Baso (BA-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:13:34'),
(73, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 10x Baso (BA-101) for Jenny Orit, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:36:06'),
(74, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 10x Cast Iron Skillet (CI-101) for Gabriel Napuli, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:39:20'),
(75, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 10x Baso (BA-101) by Jenny Orit — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:40:44'),
(76, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 8x Baso (BA-101) by Bonjor Dex — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:40:54'),
(77, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 10x Cast Iron Skillet (CI-101) by Gabriel Napuli — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:41:02'),
(78, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x wok (WO-101) by Gabriel Napuli — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:41:11'),
(79, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x wok (WO-101) by Frank Anthony S. Casipe — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:41:23'),
(80, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 19x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:43:13'),
(81, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Baso (BA-101) by Frank Anthony S. Casipe — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:47:49'),
(82, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 17x Baso (BA-101) by Frank Anthony S. Casipe — condition: missing', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:51:14'),
(83, 1, 'NIORRITOS', 'Admin', 'tool_condition_update', 'Recovered 17x Baso (BA-101): missing -> good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:55:36'),
(84, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 19x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:57:39'),
(85, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 19x Baso (BA-101) by Frank Anthony S. Casipe — condition: damaged', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 16:58:31'),
(86, 1, 'NIORRITOS', 'Admin', 'tool_condition_update', 'Repaired 5x Baso (BA-101): damaged -> minor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:01:04'),
(87, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Cast Iron Skillet as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:05:13'),
(88, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 9x Baso (damaged, returned by Jenny Orit)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:30:36'),
(89, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Baso as approved', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:30:54'),
(90, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request for Baso as fulfilled', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:30:58'),
(91, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Baso (BA-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:40:29'),
(92, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 17:59:40'),
(93, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 2x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:04:17'),
(94, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #7 (2x Baso, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:05:09'),
(95, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #7 (2x Baso, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 5 -> 3, good 21 -> 23.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:05:20'),
(96, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:18:24'),
(97, 2, 'staff', 'Staff', 'replacement_request', 'Requested replacement: 1x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:18:48'),
(98, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:19:20'),
(99, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:20:00'),
(100, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:20:40'),
(101, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 27x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:45:28'),
(102, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Baso (BA-101) for Edwina Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:46:52'),
(103, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 27x Baso (BA-101) by Frank Anthony S. Casipe — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:47:34'),
(104, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Baso (BA-101) by Edwina Casipe — condition: minor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:48:01'),
(105, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 10x Baso (BA-101) for Bonjor Dex, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:48:50'),
(106, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 10x Baso (BA-101) by Bonjor Dex — condition: minor', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:49:02'),
(107, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 9x Baso (minor-wear, returned by Bonjor Dex)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:49:40'),
(108, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #8 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:50:29'),
(109, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #8 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 3 -> 2, good 17 -> 18.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:50:33'),
(110, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #9 (9x Baso, minor-wear, responsible: Bonjor Dex — 202223456) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:50:41'),
(111, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #9 (9x Baso, minor-wear, responsible: Bonjor Dex — 202223456) as fulfilled. Stock: total 31 (unchanged), minor wear 11 -> 2, good 18 -> 27.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:50:44'),
(112, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Baso (minor-wear, returned by Bonjor Dex)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:51:04'),
(113, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #10 (1x Baso, minor-wear, responsible: Bonjor Dex — 202223456) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:51:45'),
(114, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #10 (1x Baso, minor-wear, responsible: Bonjor Dex — 202223456) as fulfilled. Stock: total 31 (unchanged), minor wear 2 -> 1, good 27 -> 28.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:51:48'),
(115, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Baso (minor-wear, returned by Edwina Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:52:02'),
(116, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #11 (1x Baso, minor-wear, responsible: Edwina Casipe — 20151543) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:52:07'),
(117, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #11 (1x Baso, minor-wear, responsible: Edwina Casipe — 20151543) as fulfilled. Stock: total 31 (unchanged), minor wear 1 -> 0, good 28 -> 29.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 18:52:09'),
(118, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 19:41:36'),
(119, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x Baso (BA-101) by Frank Anthony S. Casipe — condition: damaged', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 19:43:08'),
(120, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 5x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 19:45:24'),
(121, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #12 (5x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 19:47:28'),
(122, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #12 (5x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 7 -> 2, good 24 -> 29.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-18 19:48:11'),
(123, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 19:52:34'),
(124, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x Baso (BA-101) for Lylle Cequina, due 2026-10-26', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:06:12'),
(125, 1, 'NIORRITOS', 'Admin', 'missing_reported', 'Reported 2 x Baso (BA-101) missing from loan TXN-2026-4E3ADF - MR-00001', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:08:12'),
(126, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x Baso (BA-101) by Lylle Cequina — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:09:33'),
(127, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 10x Baso (BA-101) for Lylle Cequina, due 2026-10-26', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:14:18'),
(128, 1, 'NIORRITOS', 'Admin', 'missing_reported', 'Reported 2 x Baso (BA-101) missing from loan TXN-2026-AE8123 - MR-00002', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:18:05'),
(129, 1, 'NIORRITOS', 'Admin', 'missing_confirmed', 'Confirmed 2x Baso (BA-101) missing - MR-00002', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:19:30'),
(130, 1, 'NIORRITOS', 'Admin', 'missing_reported', 'Reported 3 x Baso (BA-101) missing from loan TXN-2026-AE8123 - MR-00003', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:30:00'),
(131, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 8x Baso (BA-101) by Lylle Cequina — condition: good', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:30:37'),
(132, 1, 'NIORRITOS', 'Admin', 'missing_recovered', 'Recovered 2x Baso (BA-101) as good - MR-00002', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:33:10'),
(133, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 10x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-26', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:34:37'),
(134, 1, 'NIORRITOS', 'Admin', 'missing_reported', 'Reported 5 x Baso (BA-101) missing from loan TXN-2026-DE0D4E - MR-00004', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:37:14'),
(135, 1, 'NIORRITOS', 'Admin', 'missing_confirmed', 'Confirmed 5x Baso (BA-101) missing - MR-00004', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-19 20:37:36'),
(136, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:38:17'),
(137, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 4x Baso (BA-101) by Frank Anthony S. Casipe — Good 2, Minor Wear 2 [batch RBmviafhx3s73ucbjd]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:49:57'),
(138, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:53:08'),
(139, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Baso (BA-101) by Frank Anthony S. Casipe — Good 1 [batch RBmviakfbkbbb64riu]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:53:50'),
(140, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Baso (BA-101) by Frank Anthony S. Casipe — Good 2 [batch RBmviakfbkbbb64riu]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:53:50'),
(141, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 2x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:55:00'),
(142, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 3x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:57:12'),
(143, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 3x Baso (BA-101) by Frank Anthony S. Casipe — Minor Wear 1, Damaged 2 [batch RBmviapi1u2sutlpwj]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:58:30'),
(144, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #13 (2x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:58:55'),
(145, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #13 (2x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 4 -> 2, good 19 -> 21.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-21 23:59:13'),
(146, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:00:10'),
(147, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #14 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:00:22'),
(148, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #14 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 2 -> 1, good 21 -> 22.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:00:25'),
(149, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 1x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:00:59'),
(150, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #15 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:01:01'),
(151, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #15 (1x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 31 (unchanged), damaged 1 -> 0, good 22 -> 23.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:01:04'),
(152, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 3x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:03:49'),
(153, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 3x Baso (BA-101) by Frank Anthony S. Casipe — Good 1, Missing 2 [MR-00005 confirmed] [batch RBmviaygkgzp1hmkrk]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:06:04'),
(154, 1, 'NIORRITOS', 'Admin', 'missing_recovered', 'Recovered 2x Baso (BA-101) as good - MR-00005', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:09:42'),
(155, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 3x Baso (BA-101) for Edwina Casipe, due 2026-10-28', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:21:49'),
(156, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 3x Baso (BA-101) by Edwina Casipe — Good 3 [batch RBmviblaujwz2rx4m3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 00:22:26'),
(157, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:02:58'),
(158, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x fork (F001-ORK) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 4]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:13:23'),
(159, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x Wine Glass (WG-09) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 4]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:13:23'),
(160, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x wok (WO-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 4]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:13:23'),
(161, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 4]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:13:23'),
(162, 1, 'NIORRITOS', 'Admin', 'missing_recovered', 'Recovered 5x Baso (BA-101) as good - MR-00004', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:13:55'),
(163, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x wok (WO-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 2]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:16:34'),
(164, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Cast Iron Skillet (CI-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 2]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:16:34'),
(165, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x fork (F001-ORK) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:19:00'),
(166, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Wine Glass (WG-09) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:19:00'),
(167, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x wok (WO-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 12:19:00'),
(168, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-22 12:22:55'),
(169, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 15:43:10'),
(170, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-22 21:20:36'),
(171, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-23 00:35:02'),
(172, NULL, NULL, NULL, 'login_failed', 'Failed login attempt for username \'aadmin\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-23 12:31:19'),
(173, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-23 12:31:25'),
(174, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 12:35:30'),
(175, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 12:36:56'),
(176, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 12:45:02'),
(177, 1, 'NIORRITOS', 'Admin', 'missing_reported', 'Reported 1 x wok (WO-101) missing from loan TXN-2026-4317D4 - MR-00006', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:12:04'),
(178, 1, 'NIORRITOS', 'Admin', 'missing_confirmed', 'Confirmed 1x wok (WO-101) missing - MR-00006', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:13:39'),
(179, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x fork (F001-ORK) by Frank Anthony S. Casipe — Good 5 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(180, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x Wine Glass (WG-09) by Frank Anthony S. Casipe — Good 5 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(181, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x wok (WO-101) by Frank Anthony S. Casipe — Good 5 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(182, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x Baso (BA-101) by Frank Anthony S. Casipe — Good 5 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(183, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x wok (WO-101) by Frank Anthony S. Casipe — Good 2 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(184, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Cast Iron Skillet (CI-101) by Frank Anthony S. Casipe — Good 2 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29');
INSERT INTO `audit_log` (`id`, `user_id`, `username_snapshot`, `role_snapshot`, `action`, `description`, `ip_address`, `user_agent`, `created_at`) VALUES
(185, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x fork (F001-ORK) by Frank Anthony S. Casipe — Good 2 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(186, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Wine Glass (WG-09) by Frank Anthony S. Casipe — Good 2 [batch RBmvkiohjneaaqnag5]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 13:17:29'),
(187, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-23 21:55:33'),
(188, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-23 21:57:04'),
(189, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-24 00:36:09'),
(190, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Baso (BA-101) - stock 31 -> 39 (added 8)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', '2026-10-24 00:49:28'),
(191, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 16:01:28'),
(192, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import: 12 added, 0 updated, 0 unchanged, 0 skipped of 12 rows (policy: overwrite)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 16:13:00'),
(193, 1, 'NIORRITOS', 'Admin', 'borrower_edit', 'Updated sections (FPST) for 1 student(s): Angelica Reyes → 1-D', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 16:22:24'),
(194, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-24 17:28:20'),
(195, 1, 'NIORRITOS', 'Admin', 'borrower_deactivate', 'Deactivated borrower Angelica Reyes', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-24 17:30:06'),
(196, 1, 'NIORRITOS', 'Admin', 'borrower_reactivate', 'Reactivated borrower Angelica Reyes', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-24 17:30:09'),
(197, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-24 17:33:20'),
(198, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import (AY 2026-2027): 1 added, 2 updated, 0 unchanged, 0 skipped of 3 rows (policy: overwrite)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 20:14:35'),
(199, 1, 'NIORRITOS', 'Admin', 'borrower_deactivate', 'Deactivated borrower Paolo Villanueva', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 20:14:44'),
(200, 1, 'NIORRITOS', 'Admin', 'borrower_reactivate', 'Reactivated borrower Paolo Villanueva', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 20:14:49'),
(201, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import: 2 added, 1 updated, 0 unchanged, 0 skipped of 3 rows (policy: overwrite)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-24 20:26:34'),
(202, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 02:24:25'),
(203, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 5x Baso (BA-101) for Frank Anthony S. Casipe, due 2026-10-31 [cart of 1]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 02:26:25'),
(204, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 5x Baso (BA-101) by Frank Anthony S. Casipe — Good 3, Damaged 1, Missing 1 [MR-00007 confirmed] [batch RBmvmqffi2rvv3s9ws]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 02:30:41'),
(205, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 21:12:20'),
(206, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 22:17:44'),
(207, 1, 'NIORRITOS', 'Admin', 'user_delete', 'Deleted user account: precious baculanta (Admin)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 22:43:41'),
(208, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]', '2026-10-25 22:51:43'),
(209, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-25 22:54:48'),
(210, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Bonjor Dex (20256789, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 00:45:57'),
(211, 1, 'NIORRITOS', 'Admin', 'borrower_edit', 'Edited borrower Angelica Reyes (2025000103)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 00:49:50'),
(212, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 01:08:41'),
(213, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 02:08:15'),
(214, 1, 'NIORRITOS', 'Admin', 'borrower_deactivate', 'Deactivated borrower Carlo Ramos', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 02:54:12'),
(215, 1, 'NIORRITOS', 'Admin', 'borrower_reactivate', 'Reactivated borrower Carlo Ramos', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 02:54:37'),
(216, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 03:21:08'),
(217, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 03:21:44'),
(218, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 03:24:11'),
(219, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 03:25:46'),
(220, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 11:01:58'),
(221, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 11:03:22'),
(222, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]', '2026-10-26 11:04:33'),
(223, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]', '2026-10-26 11:04:35'),
(224, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]', '2026-10-26 11:04:50'),
(225, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 15; 23129RAA4G Build/AQ3A.240829.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/155.0.8059.43 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/584.1.0.61.98;]', '2026-10-26 11:05:05'),
(226, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 11:09:08'),
(227, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 11:15:21'),
(228, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 11:29:47'),
(229, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 12:03:28'),
(230, 1, 'NIORRITOS', 'Admin', 'missing_replacement_requested', 'Requested replacement: 1x Baso (missing case MR-00007)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 12:15:17'),
(231, 1, 'NIORRITOS', 'Admin', 'missing_replacement_approved', 'Marked replacement request #16 (1x Baso, missing, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 12:15:34'),
(232, 1, 'NIORRITOS', 'Admin', 'missing_replacement_received', 'Marked replacement request #16 (1x Baso, missing, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Missing 1 -> 0, available 37 -> 38, total 39 (unchanged). Case MR-00007.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 12:15:49'),
(233, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 13:07:32'),
(234, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Wine Glass (WG-09) for Frank Anthony S. Casipe, due 2026-11-02 [cart of 1]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 13:32:13'),
(235, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 13:57:10'),
(236, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 13:58:50'),
(237, 2, 'staff', 'Staff', 'return', 'Returned 2x Wine Glass (WG-09) by Frank Anthony S. Casipe — Good 2 [batch RBmvoulvfsvzrlcmgq]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 14:01:12'),
(238, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Baso (BA-101) for Lylle A. Cequina, due 2026-11-02 [cart of 1]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:21:11'),
(239, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Baso (BA-101) by Lylle A. Cequina — Damaged 1 [batch RBmvovc9fo1ozwp6xy]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:22:17'),
(240, 1, 'NIORRITOS', 'Admin', 'replacement_request', 'Requested replacement: 2x Baso (damaged, returned by Frank Anthony S. Casipe)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:25:05'),
(241, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #17 (2x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:25:24'),
(242, 1, 'NIORRITOS', 'Admin', 'replacement_resolved', 'Marked replacement request #17 (2x Baso, damaged, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Stock: total 39 (unchanged), damaged 2 -> 0, good 34 -> 36.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:25:29'),
(243, 1, 'NIORRITOS', 'Admin', 'tool_create', 'Added tool Whisk (FPST-UTL-0001), qty 20, price 40', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:47:00'),
(244, 1, 'NIORRITOS', 'Admin', 'tool_edit', 'Edited tool Baso (BA-101)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 14:47:37'),
(245, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 14:53:01'),
(246, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 15:30:35'),
(247, 2, 'staff', 'Staff', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Frank Anthony S. Casipe, due 2026-10-26 [cart of 1]', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 15:39:47'),
(248, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import: 30 added, 0 updated, 0 unchanged, 0 skipped of 30 rows (policy: skip)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 15:43:50'),
(249, 1, 'NIORRITOS', 'Admin', 'borrower_edit', 'FPST masterlist import: 0 added, 15 updated, 0 unchanged, 0 skipped of 15 rows (policy: overwrite)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 15:54:46'),
(250, 1, 'NIORRITOS', 'Admin', 'tool_create', 'Added tool Whisk (FPST-UTL-0002), qty 20, price 40', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 16:11:17'),
(251, NULL, NULL, NULL, 'login_failed', 'Failed login attempt for username \'admin\'', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 16:42:17'),
(252, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 16:42:21'),
(253, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 16:55:04'),
(254, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 16:56:30'),
(255, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 16:59:10'),
(256, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 17:03:05'),
(257, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 1x Cast Iron Skillet (CI-101) for Lylle A. Cequina, due 2026-11-02 [cart of 1]', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 17:04:37'),
(258, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:08:06'),
(259, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:08:39'),
(260, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:22:18'),
(261, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:27:39'),
(262, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:28:53'),
(263, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 18:48:49'),
(264, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:01:38'),
(265, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:03:20'),
(266, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:03:50'),
(267, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 19:16:44'),
(268, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 19:20:14'),
(269, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 6x Whisk (FPST-UTL-0002) for Frank Anthony S. Casipe, due 2026-10-26 [cart of 1]', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:47:19'),
(270, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Frank Anthony S. Casipe — Good 1 [batch RBmvp70s3l8flmcgen]', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:51:33'),
(271, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 6x Whisk (FPST-UTL-0002) by Frank Anthony S. Casipe — Good 5, Missing 1 [MR-00008 confirmed] [batch RBmvp70s3l8flmcgen]', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:51:33'),
(272, 1, 'NIORRITOS', 'Admin', 'missing_recovered', 'Recovered 1x Whisk (FPST-UTL-0002) as good - MR-00008', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:54:00'),
(273, 1, 'NIORRITOS', 'Admin', 'missing_replacement_requested', 'Requested replacement: 1x wok (missing case MR-00006)', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:54:43'),
(274, 1, 'NIORRITOS', 'Admin', 'missing_replacement_approved', 'Marked replacement request #18 (1x wok, missing, responsible: Frank Anthony S. Casipe — 20222545) as approved.', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:55:14'),
(275, 1, 'NIORRITOS', 'Admin', 'missing_replacement_received', 'Marked replacement request #18 (1x wok, missing, responsible: Frank Anthony S. Casipe — 20222545) as fulfilled. Missing 1 -> 0, available 10 -> 11, total 11 (unchanged). Case MR-00006.', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 19:55:42'),
(276, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 20:14:36'),
(277, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 21:06:40'),
(278, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 21:30:41'),
(279, 1, 'NIORRITOS', 'Admin', 'stock_added', 'Added 5x Whisk (FPST-UTL-0002), total 25', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 21:32:11'),
(280, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 21:33:20'),
(281, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-26 21:55:42'),
(282, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 23:30:24'),
(283, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '192.168.1.5', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Mobile Safari/537.36', '2026-10-26 23:39:21'),
(284, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:37:24'),
(285, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:37:30'),
(286, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:37:31'),
(287, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:38:37'),
(288, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:38:38'),
(289, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:38:39'),
(290, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:38:43'),
(291, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 21:39:50'),
(292, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 4x frying pan (FP-101) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:00:47'),
(293, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 7x fork (F001-ORK) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:00:47'),
(294, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 4x Wine Glass (WG-09) for Frank Anthony S. Casipe, due 2026-10-29 [cart of 3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:00:47'),
(295, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 4x frying pan (FP-101) by Frank Anthony S. Casipe — Good 4 [batch RBmvs6n73atuthoxb3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:02:44'),
(296, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 7x fork (F001-ORK) by Frank Anthony S. Casipe — Good 7 [batch RBmvs6n73atuthoxb3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:02:44'),
(297, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 4x Wine Glass (WG-09) by Frank Anthony S. Casipe — Good 2, Damaged 1, Missing 1 [MR-00009 confirmed] [batch RBmvs6n73atuthoxb3]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:02:44'),
(298, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #19; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:05:22'),
(299, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #19: review_charge; awaiting_payment; PHP 50.00; ok; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:09:14'),
(300, 1, 'NIORRITOS', 'Admin', 'damage_loss_claim_payment', 'Charge #19: claim_payment; verification_pending; PHP 50.00; ; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:09:35'),
(301, 1, 'NIORRITOS', 'Admin', 'damage_loss_confirm_payment', 'Charge #19: confirm_payment; confirmed; PHP 50.00; okay na; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:10:25'),
(302, 1, 'NIORRITOS', 'Admin', 'stock_added', 'Added 1x Wine Glass (WG-09), total 26', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:13:49'),
(303, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #20; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:14:32'),
(304, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #20: review_charge; awaiting_payment; PHP 20.00; e3e3; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:15:55'),
(305, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #20: review_charge; awaiting_payment; PHP 20.00; e3e; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:16:20'),
(306, 1, 'NIORRITOS', 'Admin', 'damage_loss_claim_payment', 'Charge #20: claim_payment; verification_pending; PHP 20.00; ; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:16:36'),
(307, 1, 'NIORRITOS', 'Admin', 'damage_loss_confirm_payment', 'Charge #20: confirm_payment; confirmed; PHP 20.00; e3e; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 22:16:48'),
(308, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #21; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 23:58:42'),
(309, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #21: review_charge; awaiting_payment; PHP 30.00; dhhd; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 23:59:05'),
(310, 1, 'NIORRITOS', 'Admin', 'damage_loss_claim_payment', 'Charge #21: claim_payment; verification_pending; PHP 30.00; sww; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 23:59:16'),
(311, 1, 'NIORRITOS', 'Admin', 'damage_loss_confirm_payment', 'Charge #21: confirm_payment; confirmed; PHP 30.00; sswssw; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-28 23:59:26'),
(312, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 3x Baso (BA-101) for Lylle A. Cequina, due 2026-10-29 [cart of 2]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:05:08'),
(313, 1, 'NIORRITOS', 'Admin', 'borrow', 'Borrowed 2x Whisk (FPST-UTL-0002) for Lylle A. Cequina, due 2026-10-29 [cart of 2]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:05:08'),
(314, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 1x Cast Iron Skillet (CI-101) by Lylle A. Cequina — Damaged 1 [batch RBmvsb2u7wz7bm5d3g]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:05:58'),
(315, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 3x Baso (BA-101) by Lylle A. Cequina — Damaged 3 [batch RBmvsb2u7wz7bm5d3g]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:05:58'),
(316, 1, 'NIORRITOS', 'Admin', 'return', 'Returned 2x Whisk (FPST-UTL-0002) by Lylle A. Cequina — Damaged 2 [batch RBmvsb2u7wz7bm5d3g]', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:05:58'),
(317, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #22; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:37:22'),
(318, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #23; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:38:06'),
(319, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #24; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:39:08'),
(320, 1, 'NIORRITOS', 'Admin', 'damage_loss_incident', 'Filed incident #25; no charge or inventory change applied.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:39:16'),
(321, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #25: review_charge; awaiting_payment; PHP 100.00; sss; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:46:09'),
(322, 1, 'NIORRITOS', 'Admin', 'damage_loss_claim_payment', 'Charge #25: claim_payment; verification_pending; PHP 100.00; ewew; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:46:50'),
(323, 1, 'NIORRITOS', 'Admin', 'damage_loss_confirm_payment', 'Charge #25: confirm_payment; confirmed; PHP 100.00; nnnoo; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 00:47:12'),
(324, 1, 'NIORRITOS', 'Admin', 'damage_loss_review_charge', 'Charge #24: review_charge; awaiting_payment; PHP 100.00; naguba; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 01:09:42'),
(325, 1, 'NIORRITOS', 'Admin', 'damage_loss_claim_payment', 'Charge #24: claim_payment; verification_pending; PHP 100.00; gjgggj; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 01:09:57'),
(326, 1, 'NIORRITOS', 'Admin', 'damage_loss_confirm_payment', 'Charge #24: confirm_payment; confirmed; PHP 100.00; dwdwdw; inventory unchanged.', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 01:10:19'),
(327, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 12:09:45'),
(328, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 12:46:06'),
(329, 1, 'NIORRITOS', 'Admin', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 17:29:47'),
(330, 2, 'staff', 'Staff', 'login', 'Logged in', '::1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Mobile Safari/537.36', '2026-10-29 18:01:49'),
(331, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import (AY 2026-2027): 2 added, 0 updated, 0 unchanged, 0 skipped of 2 rows (policy: overwrite)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 18:49:53'),
(332, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'Added borrower Nestor T. Sasutana (20222780, Student)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 19:19:24'),
(333, 1, 'NIORRITOS', 'Admin', 'borrower_deactivate', 'Deactivated borrower Bonjor Dex', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 19:31:37'),
(334, 1, 'NIORRITOS', 'Admin', 'borrower_reactivate', 'Reactivated borrower Bonjor Dex', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 19:31:47'),
(335, 1, 'NIORRITOS', 'Admin', 'borrower_create', 'FPST masterlist import [TVL Grade 12]: 12 added, 0 updated, 0 unchanged, 0 skipped of 12 rows (policy: skip)', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36 Edg/156.0.0.0', '2026-10-29 20:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `borrowers`
--

CREATE TABLE `borrowers` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `type` enum('Student','Faculty','Staff','Guest') NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `year_level` varchar(30) DEFAULT NULL,
  `active_borrows` int(11) NOT NULL DEFAULT 0,
  `total_borrows` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=borrowable, 0=soft-deactivated by CMS sync',
  `last_synced_at` datetime DEFAULT NULL COMMENT 'Last time CMS pushed an update for this borrower',
  `source` varchar(32) DEFAULT NULL COMMENT 'cms_push for sync-created rows, NULL for manual'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrower_enrollments`
--

CREATE TABLE `borrower_enrollments` (
  `id` int(11) NOT NULL,
  `borrower_id` int(11) NOT NULL COMMENT 'FK -> borrowers.id',
  `cms_section_id` int(10) UNSIGNED NOT NULL COMMENT 'CMS sections.id',
  `cms_subject_id` int(11) NOT NULL COMMENT 'CMS subjects.id',
  `course` varchar(80) NOT NULL COMMENT 'Denormalized from sections.course for filtering',
  `section_name` varchar(80) NOT NULL COMMENT 'Denormalized from sections.section_name',
  `year_level` varchar(30) DEFAULT NULL,
  `subject_code` varchar(20) NOT NULL COMMENT 'Denormalized from subjects.subject_code',
  `subject_name` varchar(100) NOT NULL COMMENT 'Denormalized from subjects.subject_name',
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=current enrollment, 0=withdrawn in CMS',
  `synced_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_adjustments`
--

CREATE TABLE `inventory_adjustments` (
  `id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `action` enum('repair','recover','qty_edit') NOT NULL,
  `from_state` varchar(20) DEFAULT NULL,
  `to_state` varchar(20) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_resolutions`
--

CREATE TABLE `inventory_resolutions` (
  `id` int(11) NOT NULL,
  `charge_case_id` int(11) NOT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `affected_quantity` int(11) NOT NULL,
  `status` varchar(40) NOT NULL DEFAULT 'awaiting_action',
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `received_quantity` int(11) NOT NULL DEFAULT 0,
  `restored_quantity` int(11) NOT NULL DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  `completed_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_resolution_events`
--

CREATE TABLE `inventory_resolution_events` (
  `id` int(11) NOT NULL,
  `resolution_id` int(11) NOT NULL,
  `old_status` varchar(40) NOT NULL,
  `new_status` varchar(40) NOT NULL,
  `notes` varchar(500) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_resolution_receipts`
--

CREATE TABLE `inventory_resolution_receipts` (
  `id` int(11) NOT NULL,
  `resolution_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `event_kind` varchar(20) NOT NULL,
  `disposition` varchar(24) NOT NULL,
  `received_date` date NOT NULL,
  `reference_number` varchar(100) NOT NULL DEFAULT '',
  `notes` varchar(500) NOT NULL DEFAULT '',
  `stock_history_id` int(11) DEFAULT NULL,
  `removal_history_id` int(11) DEFAULT NULL,
  `adjustment_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(120) NOT NULL,
  `request_token` varchar(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `payload_hash` char(64) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `missing_reports`
--

CREATE TABLE `missing_reports` (
  `id` int(11) NOT NULL,
  `report_no` varchar(20) NOT NULL,
  `request_token` varchar(64) DEFAULT NULL,
  `borrow_txn_id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `borrower_name_snapshot` varchar(150) DEFAULT NULL,
  `borrower_id_number_snapshot` varchar(50) DEFAULT NULL,
  `qty_reported` int(11) NOT NULL,
  `qty_missing` int(11) NOT NULL DEFAULT 0,
  `qty_replaced` int(11) NOT NULL DEFAULT 0,
  `qty_recovered` int(11) NOT NULL DEFAULT 0,
  `qty_surplus` int(11) NOT NULL DEFAULT 0,
  `missing_date` date NOT NULL,
  `reason` varchar(255) NOT NULL,
  `investigation_notes` text DEFAULT NULL,
  `status` enum('pending','confirmed','resolved','rejected') NOT NULL DEFAULT 'pending',
  `open_key` int(11) DEFAULT NULL,
  `reported_by` int(11) DEFAULT NULL,
  `reported_by_name` varchar(120) DEFAULT NULL,
  `reported_at` datetime NOT NULL DEFAULT current_timestamp(),
  `confirmed_by` int(11) DEFAULT NULL,
  `confirmed_by_name` varchar(120) DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `decision_notes` varchar(500) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `missing_report_events`
--

CREATE TABLE `missing_report_events` (
  `id` int(11) NOT NULL,
  `report_id` int(11) NOT NULL,
  `action` varchar(30) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 0,
  `detail` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(120) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `replacement_incident_sources`
--

CREATE TABLE `replacement_incident_sources` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `return_transaction_id` int(11) DEFAULT NULL,
  `missing_report_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `replacement_payment_claims`
--

CREATE TABLE `replacement_payment_claims` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `receipt_number` varchar(80) NOT NULL,
  `payment_date` date NOT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'pending',
  `charge_version` int(11) NOT NULL,
  `submitted_by` int(11) DEFAULT NULL,
  `submitted_by_name` varchar(120) NOT NULL,
  `submitted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `verified_by` int(11) DEFAULT NULL,
  `verified_by_name` varchar(120) DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verification_notes` varchar(500) DEFAULT NULL,
  `active_receipt` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `active_request_id` int(11) DEFAULT NULL,
  `verified_by_role` varchar(24) DEFAULT NULL,
  `voided_by` int(11) DEFAULT NULL,
  `voided_by_name` varchar(120) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `void_reason` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `replacement_requests`
--

CREATE TABLE `replacement_requests` (
  `id` int(11) NOT NULL,
  `tool_id` int(11) DEFAULT NULL COMMENT 'NULL if the tool no longer exists / was fully removed',
  `tool_name_snapshot` varchar(150) NOT NULL COMMENT 'Tool name at time of request, kept even if the tool row is later deleted',
  `reason` varchar(20) DEFAULT 'damaged',
  `responsible_borrower_id` int(11) DEFAULT NULL,
  `responsible_name_snapshot` varchar(150) DEFAULT NULL,
  `missing_report_id` int(11) DEFAULT NULL,
  `quantity_needed` int(11) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','fulfilled') NOT NULL DEFAULT 'pending',
  `requested_by` int(11) DEFAULT NULL,
  `resolved_by` int(11) DEFAULT NULL COMMENT 'FK -> users.id',
  `resolution_notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  `writeoff_applied` tinyint(1) NOT NULL DEFAULT 0,
  `workflow_mode` varchar(20) NOT NULL DEFAULT 'legacy',
  `financial_status` varchar(24) NOT NULL DEFAULT 'legacy',
  `responsibility` varchar(24) NOT NULL DEFAULT 'unreviewed',
  `incident_quantity` int(11) DEFAULT NULL,
  `amount_due` decimal(12,2) DEFAULT NULL,
  `charge_version` int(11) NOT NULL DEFAULT 0,
  `payment_version` int(11) NOT NULL DEFAULT 0,
  `needs_financial_review` tinyint(1) NOT NULL DEFAULT 0,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_by_name` varchar(120) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `financial_closed_at` datetime DEFAULT NULL,
  `submission_token` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `requested_by_snapshot` varchar(120) DEFAULT NULL,
  `charge_assessed_at` datetime DEFAULT NULL,
  `case_completed_at` datetime DEFAULT NULL,
  `case_completed_by` int(11) DEFAULT NULL,
  `parent_case_id` int(11) DEFAULT NULL,
  `assessed_unit_charge` decimal(12,2) DEFAULT NULL,
  `line_subtotal` decimal(12,2) DEFAULT NULL,
  `tool_code_snapshot` varchar(50) DEFAULT NULL,
  `inventory_status` varchar(32) NOT NULL DEFAULT 'Pending Review'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `replacement_request_events`
--

CREATE TABLE `replacement_request_events` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `action` varchar(40) NOT NULL,
  `before_state` longtext DEFAULT NULL,
  `after_state` longtext DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(120) NOT NULL,
  `user_role` varchar(24) NOT NULL,
  `request_token` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL,
  `payload_hash` char(64) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stock_history`
--

CREATE TABLE `stock_history` (
  `id` int(11) NOT NULL,
  `tool_id` int(11) NOT NULL,
  `tool_name` varchar(150) NOT NULL,
  `transaction_type` enum('Stock Added','Stock Removed') NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'Units added or removed (always positive)',
  `previous_stock` int(11) NOT NULL COMMENT 'tools.quantity before the change',
  `updated_stock` int(11) NOT NULL COMMENT 'tools.quantity after the change',
  `remarks` varchar(500) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `event_kind` varchar(16) NOT NULL DEFAULT 'adjustment',
  `tool_code` varchar(50) DEFAULT NULL,
  `request_token` varchar(64) CHARACTER SET ascii COLLATE ascii_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category` varchar(80) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `original_quantity` int(11) DEFAULT NULL COMMENT 'Quantity when the tool was first registered. NULL = unknown (tool predates this column)',
  `available` int(11) NOT NULL DEFAULT 0,
  `minor_qty` int(11) NOT NULL DEFAULT 0 COMMENT 'Subset of `available` that has minor wear',
  `damaged_qty` int(11) NOT NULL DEFAULT 0 COMMENT 'Present but not borrowable until repaired and cleared',
  `missing_qty` int(11) NOT NULL DEFAULT 0 COMMENT 'Cannot be accounted for; still part of `quantity`',
  `min_stock` int(11) NOT NULL DEFAULT 1,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=active/borrowable, 0=retired (soft-removed, transaction history kept)',
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `replaceable_qty` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tool_sku_issued`
--

CREATE TABLE `tool_sku_issued` (
  `sku` varchar(50) NOT NULL,
  `category_code` varchar(8) DEFAULT NULL,
  `sequence_number` int(10) UNSIGNED DEFAULT NULL,
  `tool_id` int(11) DEFAULT NULL,
  `issued_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tool_sku_sequences`
--

CREATE TABLE `tool_sku_sequences` (
  `category_name` varchar(80) NOT NULL,
  `category_code` varchar(8) NOT NULL,
  `last_number` int(10) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tool_sku_sequences`
--

INSERT INTO `tool_sku_sequences` (`category_name`, `category_code`, `last_number`) VALUES
('Accessories', 'ACC', 0),
('Cookware', 'CKW', 0),
('Cutleries', 'CUT', 0),
('Dinnerware', 'DIN', 0),
('Glassware', 'GLS', 0),
('Measuring Tools', 'MEA', 0),
('Utensils', 'UTL', 2);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `txn_id` varchar(30) NOT NULL,
  `borrow_txn_id` int(11) DEFAULT NULL,
  `type` enum('borrow','return') NOT NULL,
  `tool_id` int(11) NOT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `status` enum('active','returned') NOT NULL DEFAULT 'active',
  `is_late` tinyint(1) NOT NULL DEFAULT 0,
  `condition` enum('good','minor','damaged','missing') DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `returnee_name` varchar(150) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `due_time` time DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `qty` int(11) NOT NULL DEFAULT 1,
  `qty_returned` int(11) NOT NULL DEFAULT 0,
  `qty_missing` int(11) NOT NULL DEFAULT 0,
  `borrower_name_snapshot` varchar(150) DEFAULT NULL,
  `borrower_id_number_snapshot` varchar(50) DEFAULT NULL,
  `return_batch` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Department Admin',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'NIORRITOS', 'admin', 'admin@school.edu', '$2y$10$oCLk5miIvA/taNF7D4ROYe7XxdIcDwCe/aYgxdhrz0H0.0hTPQ2Im', 'Admin', '2026-07-20 22:19:22'),
(2, 'staff', 'staff', 'staff@school.edu', '$2y$10$b0aUD0fi.mlCUjYuzWb3Mu.it4.AU4fnvYQqK5sYNGQeKSrrQilWO', 'Staff', '2026-09-16 14:48:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audit_user` (`user_id`),
  ADD KEY `idx_audit_action` (`action`),
  ADD KEY `idx_audit_created` (`created_at`);

--
-- Indexes for table `borrowers`
--
ALTER TABLE `borrowers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_number` (`id_number`),
  ADD KEY `idx_borrowers_is_active` (`is_active`),
  ADD KEY `idx_borrowers_name` (`full_name`),
  ADD KEY `idx_borrowers_type_active` (`type`,`is_active`);

--
-- Indexes for table `borrower_enrollments`
--
ALTER TABLE `borrower_enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_borrower_section_subject` (`cms_section_id`,`cms_subject_id`,`borrower_id`),
  ADD KEY `idx_be_borrower` (`borrower_id`),
  ADD KEY `idx_be_active` (`is_active`),
  ADD KEY `idx_be_course` (`course`),
  ADD KEY `idx_enroll_borrower` (`borrower_id`,`is_active`,`cms_subject_id`);

--
-- Indexes for table `inventory_adjustments`
--
ALTER TABLE `inventory_adjustments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_adj_tool` (`tool_id`,`created_at`),
  ADD KEY `fk_adj_user` (`user_id`);

--
-- Indexes for table `inventory_resolutions`
--
ALTER TABLE `inventory_resolutions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_resolution_case` (`charge_case_id`),
  ADD KEY `idx_resolution_status` (`status`);

--
-- Indexes for table `inventory_resolution_events`
--
ALTER TABLE `inventory_resolution_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_resolution_events` (`resolution_id`,`id`);

--
-- Indexes for table `inventory_resolution_receipts`
--
ALTER TABLE `inventory_resolution_receipts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_resolution_receipt_token` (`request_token`),
  ADD KEY `idx_resolution_receipt` (`resolution_id`,`id`);

--
-- Indexes for table `missing_reports`
--
ALTER TABLE `missing_reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_mr_report_no` (`report_no`),
  ADD UNIQUE KEY `uq_mr_token` (`request_token`),
  ADD UNIQUE KEY `uq_mr_one_pending` (`open_key`),
  ADD KEY `idx_mr_loan` (`borrow_txn_id`),
  ADD KEY `idx_mr_tool` (`tool_id`),
  ADD KEY `idx_mr_status` (`status`);

--
-- Indexes for table `missing_report_events`
--
ALTER TABLE `missing_report_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_mre_report` (`report_id`);

--
-- Indexes for table `replacement_incident_sources`
--
ALTER TABLE `replacement_incident_sources`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ris_return` (`request_id`,`return_transaction_id`),
  ADD UNIQUE KEY `uq_ris_missing` (`request_id`,`missing_report_id`),
  ADD KEY `idx_ris_return` (`return_transaction_id`),
  ADD KEY `idx_ris_missing` (`missing_report_id`);

--
-- Indexes for table `replacement_payment_claims`
--
ALTER TABLE `replacement_payment_claims`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rpc_receipt` (`active_receipt`),
  ADD UNIQUE KEY `uq_rpc_active_request` (`active_request_id`),
  ADD KEY `idx_rpc_request` (`request_id`,`id`),
  ADD KEY `fk_rpc_submitter` (`submitted_by`),
  ADD KEY `fk_rpc_verifier` (`verified_by`),
  ADD KEY `idx_rpc_collection` (`status`,`payment_date`,`request_id`);

--
-- Indexes for table `replacement_requests`
--
ALTER TABLE `replacement_requests`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rr_submission` (`submission_token`),
  ADD KEY `idx_rr_status` (`status`),
  ADD KEY `idx_rr_tool` (`tool_id`),
  ADD KEY `fk_rr_requested_by` (`requested_by`),
  ADD KEY `fk_rr_resolved_by` (`resolved_by`),
  ADD KEY `idx_rr_responsible` (`responsible_borrower_id`),
  ADD KEY `idx_rr_missing_report` (`missing_report_id`),
  ADD KEY `idx_rr_financial` (`workflow_mode`,`financial_status`,`needs_financial_review`),
  ADD KEY `idx_rr_assessed` (`charge_assessed_at`),
  ADD KEY `idx_case_completed` (`workflow_mode`,`case_completed_at`,`id`),
  ADD KEY `idx_charge_parent` (`parent_case_id`,`id`);

--
-- Indexes for table `replacement_request_events`
--
ALTER TABLE `replacement_request_events`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rre_token` (`request_token`),
  ADD KEY `idx_rre_request` (`request_id`,`id`),
  ADD KEY `fk_rre_actor` (`user_id`);

--
-- Indexes for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_stock_request` (`request_token`),
  ADD KEY `idx_sh_tool` (`tool_id`,`created_at`),
  ADD KEY `idx_sh_user` (`user_id`),
  ADD KEY `idx_sh_created` (`created_at`),
  ADD KEY `idx_stock_registration` (`tool_id`,`event_kind`),
  ADD KEY `idx_stock_created` (`created_at`,`id`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD UNIQUE KEY `uq_tools_code` (`code`);

--
-- Indexes for table `tool_sku_issued`
--
ALTER TABLE `tool_sku_issued`
  ADD PRIMARY KEY (`sku`),
  ADD KEY `idx_sku_sequence` (`category_code`,`sequence_number`);

--
-- Indexes for table `tool_sku_sequences`
--
ALTER TABLE `tool_sku_sequences`
  ADD PRIMARY KEY (`category_name`),
  ADD UNIQUE KEY `category_code` (`category_code`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `txn_id` (`txn_id`),
  ADD KEY `borrower_id` (`borrower_id`),
  ADD KEY `idx_transactions_type` (`type`),
  ADD KEY `idx_transactions_status` (`status`),
  ADD KEY `idx_transactions_tool` (`tool_id`),
  ADD KEY `idx_transactions_date` (`created_at`),
  ADD KEY `idx_borrow_txn` (`borrow_txn_id`),
  ADD KEY `idx_txn_borrower` (`borrower_id`,`type`,`status`,`due_date`),
  ADD KEY `idx_txn_type_created` (`type`,`created_at`),
  ADD KEY `idx_txn_type_status` (`type`,`status`,`created_at`),
  ADD KEY `idx_txn_overdue` (`type`,`status`,`due_date`),
  ADD KEY `idx_txn_tool_type_status` (`tool_id`,`type`,`status`),
  ADD KEY `idx_txn_return_batch` (`return_batch`,`borrow_txn_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=336;

--
-- AUTO_INCREMENT for table `borrowers`
--
ALTER TABLE `borrowers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `borrower_enrollments`
--
ALTER TABLE `borrower_enrollments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;

--
-- AUTO_INCREMENT for table `inventory_adjustments`
--
ALTER TABLE `inventory_adjustments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `inventory_resolutions`
--
ALTER TABLE `inventory_resolutions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `inventory_resolution_events`
--
ALTER TABLE `inventory_resolution_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `inventory_resolution_receipts`
--
ALTER TABLE `inventory_resolution_receipts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `missing_reports`
--
ALTER TABLE `missing_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `missing_report_events`
--
ALTER TABLE `missing_report_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `replacement_incident_sources`
--
ALTER TABLE `replacement_incident_sources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `replacement_payment_claims`
--
ALTER TABLE `replacement_payment_claims`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `replacement_requests`
--
ALTER TABLE `replacement_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `replacement_request_events`
--
ALTER TABLE `replacement_request_events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `stock_history`
--
ALTER TABLE `stock_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `borrower_enrollments`
--
ALTER TABLE `borrower_enrollments`
  ADD CONSTRAINT `fk_be_borrower` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `inventory_adjustments`
--
ALTER TABLE `inventory_adjustments`
  ADD CONSTRAINT `fk_adj_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`),
  ADD CONSTRAINT `fk_adj_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `missing_reports`
--
ALTER TABLE `missing_reports`
  ADD CONSTRAINT `fk_mr_loan` FOREIGN KEY (`borrow_txn_id`) REFERENCES `transactions` (`id`),
  ADD CONSTRAINT `fk_mr_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`);

--
-- Constraints for table `missing_report_events`
--
ALTER TABLE `missing_report_events`
  ADD CONSTRAINT `fk_mre_report` FOREIGN KEY (`report_id`) REFERENCES `missing_reports` (`id`);

--
-- Constraints for table `replacement_incident_sources`
--
ALTER TABLE `replacement_incident_sources`
  ADD CONSTRAINT `fk_ris_missing` FOREIGN KEY (`missing_report_id`) REFERENCES `missing_reports` (`id`),
  ADD CONSTRAINT `fk_ris_request` FOREIGN KEY (`request_id`) REFERENCES `replacement_requests` (`id`),
  ADD CONSTRAINT `fk_ris_return` FOREIGN KEY (`return_transaction_id`) REFERENCES `transactions` (`id`);

--
-- Constraints for table `replacement_payment_claims`
--
ALTER TABLE `replacement_payment_claims`
  ADD CONSTRAINT `fk_rpc_request` FOREIGN KEY (`request_id`) REFERENCES `replacement_requests` (`id`),
  ADD CONSTRAINT `fk_rpc_submitter` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_rpc_verifier` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `replacement_requests`
--
ALTER TABLE `replacement_requests`
  ADD CONSTRAINT `fk_rr_missing_report` FOREIGN KEY (`missing_report_id`) REFERENCES `missing_reports` (`id`),
  ADD CONSTRAINT `fk_rr_requested_by` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_rr_resolved_by` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_rr_responsible` FOREIGN KEY (`responsible_borrower_id`) REFERENCES `borrowers` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_rr_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `replacement_request_events`
--
ALTER TABLE `replacement_request_events`
  ADD CONSTRAINT `fk_rre_actor` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_rre_request` FOREIGN KEY (`request_id`) REFERENCES `replacement_requests` (`id`);

--
-- Constraints for table `stock_history`
--
ALTER TABLE `stock_history`
  ADD CONSTRAINT `fk_sh_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`),
  ADD CONSTRAINT `fk_sh_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_txn_borrower` FOREIGN KEY (`borrower_id`) REFERENCES `borrowers` (`id`),
  ADD CONSTRAINT `fk_txn_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
