<?php if (!empty($isAdmin)): ?>
<div class="modal-overlay" id="backupSettingsModal">
  <div class="modal tt-backup" role="dialog" aria-modal="true" aria-labelledby="backupTitle">
    <div class="modal-header"><h3 class="modal-title" id="backupTitle"><i class="fas fa-shield-halved"></i> Database Backup</h3><button class="modal-close" aria-label="Close backup settings" onclick="closeModal('backupSettingsModal')"><i class="fas fa-times"></i></button></div>
    <div class="modal-body">
      <p class="tt-backup-note">Encrypted database backups saved on this PC. Google Drive for Desktop syncs your chosen folder automatically when it is running and connected.</p>
      <p id="backupMessage" class="tt-backup-message" role="status" aria-live="polite"></p>
      <div class="tt-backup-stats"><div><span>Last successful backup</span><b id="backupLast">Loading…</b></div><div><span>Latest operation</span><b id="backupStatus">Loading…</b></div></div>
      <div id="backupSetup" hidden><p>On the XAMPP PC, right-click <code>backups/setup-backups.ps1</code> and run with PowerShell using the same Windows account as XAMPP. Then refresh this panel.</p></div>
      <div id="backupControls" hidden>
        <div class="tt-backup-heading"><h4>Backup destination</h4><button type="button" class="card-btn primary tt-backup-control" onclick="ttBackupNow()"><i class="fas fa-database"></i> Backup Now</button></div>
        <label class="field-label" for="backupFolder">Windows folder outside htdocs</label>
        <input class="form-input-full tt-backup-control" id="backupFolder" type="text" placeholder="C:\ToolTrackBackups" autocomplete="off">
        <label class="field-label" for="backupAdminPassword">Administrator password (for settings, recovery key export, and restore)</label>
        <input class="form-input-full tt-backup-control" id="backupAdminPassword" type="password" autocomplete="current-password">
        <div class="tt-backup-actions"><button type="button" class="card-btn secondary tt-backup-control" onclick="ttBackupSaveFolder()">Save folder</button><button type="button" class="card-btn secondary tt-backup-control" onclick="ttBackupExportKey()"><i class="fas fa-key"></i> Download recovery key</button></div>
        <p class="tt-backup-note">Keep your recovery key offline, separate from the backups. It is needed after a PC failure. Backups are never automatically deleted.</p>
        <details class="tt-backup-help"><summary>Google Drive and daily backup setup</summary>
          <ol><li>Install Google Drive for Desktop and sign in to your Google account.</li><li>Open its tray icon → Settings → Preferences → Folders from your computer → Add folder. Select the exact backup destination above and choose <b>Sync with Google Drive</b>.</li><li>Click Backup Now, then check the Drive tray icon to confirm the upload finished. ToolTrack reports local backup status; it cannot verify cloud upload status.</li><li>For daily backups, create a Windows Task Scheduler task: program <code>C:\xampp\php\php.exe</code>, arguments <code>"C:\xampp\htdocs\tooltrack\backup.php" backup</code>. Run as the Windows user who runs XAMPP. Enable “Run task as soon as possible after a scheduled start is missed”.</li></ol>
          <p>MySQL must be running. Drive for Desktop uploads while you are signed in and it is running. Backups use your account’s available free storage.</p>
          <a href="backups/README.md" target="_blank" rel="noopener">Full setup, restore and recovery instructions</a>
        </details>
        <div class="tt-backup-heading"><h4>Backup history</h4><button type="button" class="card-btn secondary tt-backup-control" onclick="ttLoadBackups()">Refresh</button></div>
        <div id="backupHistory" class="tt-backup-history"></div>
        <div class="tt-backup-restore">
          <h4>Restore a backup</h4>
          <p class="tt-backup-note">Restoring replaces the current database, including accounts and passwords. The backup must pass a test restore first. A safety backup is created before any live records are replaced. Test databases are retained for review.</p>
          <p id="backupSelected">Select a backup from history, or upload an encrypted backup below.</p>
          <label class="field-label" for="backupUpload">Encrypted backup file (optional when selected from history)</label>
          <input type="file" class="form-input-full tt-backup-control" id="backupUpload" accept=".ttbackup" onchange="ttBackupUploadChanged()">
          <label class="field-label" for="backupRecovery">Recovery key file (only for a backup from another PC/key)</label>
          <input type="file" class="form-input-full tt-backup-control" id="backupRecovery" accept=".json">
          <label class="field-label" for="backupConfirmation">To replace live data, type RESTORE tooltrack_db</label>
          <input type="text" class="form-input-full tt-backup-control" id="backupConfirmation" autocomplete="off" spellcheck="false">
          <div class="tt-backup-actions"><button type="button" class="card-btn secondary tt-backup-control" onclick="ttBackupRestore(false)">Test restore only</button><button type="button" class="btn btn-danger tt-backup-control" onclick="ttBackupRestore(true)">Restore live database</button></div>
        </div>
      </div>
    </div>
    <div class="modal-footer"><button type="button" class="btn btn-gray" onclick="closeModal('backupSettingsModal')">Close</button></div>
  </div>
</div>
<?php endif; ?>