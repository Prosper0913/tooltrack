# ToolTrack database backup and restore

This feature uses the MySQL/MariaDB clients bundled with XAMPP, PHP zlib and OpenSSL, Google Drive for Desktop, and optionally Windows Task Scheduler. No paid service, Google Drive API, or application OAuth integration is used. Available Google account storage still applies.

## Start here

1. Start Apache and MySQL in XAMPP.
2. Sign in to ToolTrack as an Admin. Open the gear icon (Account Settings), then **Database Backup & Restore**. You can also open `http://localhost/tooltrack/backup_manager.html`.
3. The protected storage has already been initialized on this PC. Its default backup destination is **C:\xampp\ToolTrackBackups**. You may change this to another local Windows folder outside every web-served directory. Enter your current administrator password and click **Save folder**.
4. Click **Download recovery key**, using your administrator password. Keep this JSON file on an offline USB drive or other secure location separate from the backup folder. Anyone with both the key and a backup can read the database. A lost key cannot be recovered from the encrypted backup.
5. Click **Backup Now**. A success means the database export was compressed, encrypted, decrypted again, hash-verified and saved locally. Use **Download Backup** in history to download the encrypted file.
6. Configure Drive for Desktop below to upload the saved files automatically.

Backups contain the entire `tooltrack_db` application database: table definitions and records, views, routines, triggers and events where present. MySQL server accounts, other databases, PHP source code, XAMPP configuration and filesystem uploads are not part of a database backup. Keep a separate copy of the application files for disaster recovery.

## Google Drive for Desktop (one-time setup)

1. Install [Google Drive for Desktop](https://support.google.com/drive/answer/10838124?hl=en) and sign in to the Google account you want to use.
2. Click the Drive icon in the Windows system tray, then **Settings > Preferences**.
3. Under **Folders from your computer / My Computer**, click **Add folder**.
4. Choose the exact local folder configured in ToolTrack, for example `C:\xampp\ToolTrackBackups`.
5. Choose **Sync with Google Drive** and save the preference. Do not select the private key folder or `htdocs` for this backup workflow.
6. Make a backup and check the Drive tray icon until the upload is complete. Look under **Computers** in Google Drive for a folder synced from your computer.

ToolTrack intentionally has no access to your Google account. It cannot confirm cloud upload, account selection, remaining quota, or internet connectivity. History reports local creation and verification only. Drive uploads while it is running, signed in, connected and has available storage. Local backups continue to work offline and upload later. Drive syncing also propagates file deletions, so do not delete the only copy of a backup you still need.

## Daily automatic backups (optional)

No scheduled task has been installed automatically.

1. Open **Windows Task Scheduler > Create Task**.
2. Name it `ToolTrack Daily Backup`. Use the same Windows account that runs XAMPP and owns the private backup folder. For the simplest setup, choose **Run only when user is logged on**.
3. Add a **Daily** trigger at a time the PC and MySQL normally run, such as **5:00 PM**. Task Scheduler uses the PC's local time; check that Windows is set to your intended time zone (Asia/Manila).
4. Add a **Start a program** action:
   - Program: `C:\xampp\php\php.exe`
   - Arguments: `"C:\xampp\htdocs\tooltrack\backup.php" backup`
   - Start in: `C:\xampp\htdocs\tooltrack`
5. In Settings, enable **Run task as soon as possible after a scheduled start is missed** and **Do not start a new instance** if one is running.
6. Save, right-click the task, and choose **Run**. Confirm Last Run Result is `0x0` and a new successful backup appears in ToolTrack history. A nonzero result indicates an error; inspect history and the PHP error log.

Alternatively, `run_backup.bat` runs the same CLI command without pausing. The task uses the existing protected key; no password is placed in the scheduled command. MySQL must be running. The PC cannot back up while shut down. Google Drive for Desktop uploads when your interactive session is signed in and Drive is running.

## Restore safely

Restoring REPLACES the database, including inventory, transactions, borrowers, users and passwords. It does not merge records. The feature never performs a live restore merely by selecting or uploading a file.

1. Ask other users to finish their work and close SQL tools such as phpMyAdmin. External SQL clients do not participate in the application's maintenance lock.
2. Select **Use for restore** beside a backup in history, or upload an encrypted `.ttbackup` file. Backups from another PC/key also require the corresponding recovery-key JSON file. Uploaded keys are used for that operation, not saved as the PC's current key.
3. Click **Test restore only** first. This imports into a brand-new `tooltrack_restore_test_*` database and compares schema defaults, each table's structure, exact row count, extended checksum, and database objects. The database name appears in history. Test databases are retained for review, never automatically deleted.
4. To restore the live database, enter the CURRENT administrator password, type **RESTORE tooltrack_db**, click **Restore live database**, and approve the replacement warning.
5. The server authenticates the archive, repeats the test restore, takes an exclusive maintenance lock, and creates a verified encrypted safety backup of the current data. If any prerequisite fails, it does not replace live records.
6. It restores and verifies the live database. If import/verification fails, it attempts to restore and verify the safety backup automatically. If recovery also fails or the process is interrupted, maintenance remains enabled.
7. After success, existing sessions must sign in again using accounts/passwords from the restored backup. The safety backup remains in history with reason `before_restore`.

For uploads larger than PHP's `upload_max_filesize` or `post_max_size`, adjust both in `C:\xampp\php\php.ini` and restart Apache. Selecting a backup already in server history avoids upload limits. Allow enough free disk space for the database export, encrypted backup, temporary compression/verification files, test database and safety backup.

Encrypted backups include routines, views, triggers and events. Automatic restore deliberately stops before touching live records if the SQL contains database-qualified references, database creation/USE commands, or scheduled database events. Such objects need a reviewed manual restore to avoid touching another schema or executing scheduled tasks in a test database. The installed database currently has 13 base tables and no views, routines, triggers or events; its automatic restore has passed testing.

## Interrupted restore / emergency recovery

A failed or interrupted destructive restore leaves this report outside the web root:

`C:\xampp\tooltrack-private\recovery-required.json`

Normal application and CMS requests then return maintenance status. Do NOT remove the report just to re-enable the application: the database may be incomplete.

1. Restart MySQL if needed. Keep external SQL tools idle.
2. From PowerShell on the XAMPP PC, explicitly approve restoring the recorded pre-restore safety backup:

```powershell
& 'C:\xampp\php\php.exe' 'C:\xampp\htdocs\tooltrack\backup.php' recover-safety '--confirm=RESTORE tooltrack_db'
```

3. This command requires a pending recovery report and the intact recorded safety backup. It verifies/decrypts the archive, test-restores it, restores the safety version, verifies the result, expires sessions and clears maintenance only after success. It does not run without the exact confirmation argument.
4. If it fails, keep the report, backup files and key intact. Inspect the PHP error log and report before attempting manual recovery. Missing/corrupt files, a stopped MySQL service or disk-full conditions need to be resolved first.

The normal CLI runner cannot restore arbitrary files. `recover-safety` is for the specific pre-restore backup recorded in the interruption report.

## Reinstall / move to another PC

Keep a copy of your application code, encrypted backups and recovery-key JSON. Install a compatible XAMPP version, restore the application code, configure its database credentials and set up an initial application database/admin account. Run backup setup on the new PC, sign in, then use the encrypted backup plus its original recovery key in the restore panel. After restoring, use the accounts contained in that backup. Export the NEW PC's recovery key for future backups; the old key remains necessary for old archives.

To initialize backup storage after a fresh install, run as the Windows user who runs XAMPP:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\xampp\htdocs\tooltrack\backups\setup-backups.ps1'
```

This bypass applies only to that process; it does not change Windows' execution policy. Setup preserves any existing key/configuration. It restricts `C:\xampp\tooltrack-private` to the current Windows user, SYSTEM and Administrators. If Apache is a Windows service under another account, give ONLY that service account the necessary access to the private folder and destination. Do not grant Everyone access.

## Files, security and verification

- Encrypted archives: configured folder, initially `C:\xampp\ToolTrackBackups`, named `tooltrack_YYYY-MM-DD_HH-MM-SS_<random>.ttbackup`.
- Key, configuration, operation history, maintenance locks and plaintext working files: `C:\xampp\tooltrack-private`, outside `htdocs`, restricted by Windows ACLs. Never sync this directory to the same Drive folder as the archives.
- Temporary files are removed when an operation finishes. A power loss can leave working files; they stay in the protected private folder. Do not expose that folder through Apache aliases.
- Compression is gzip. Encryption is chunked AES-256-GCM with a random 256-bit key, independent random nonces, authenticated metadata and ordered blocks, plus an authenticated end marker. SQL length/SHA-256 and archive SHA-256 are checked before success or restore.
- Private history persists across browser sessions and restarts. The UI shows the newest 100 operations; older history remains on disk. Missing/moved files are not offered for download. Changing destination does not move or remove old backups.
- No automatic backup pruning, test-database cleanup, Google sign-in, Drive installation or scheduled-task registration is performed.
- Admin UI visibility is backed by session AND current-database role checks. Mutating actions and downloads require a session-bound CSRF token. Folder changes, key export and live restore require current administrator password confirmation.
- Application and CMS requests hold shared locks; restore takes an exclusive lock, and all backup/restore operations have an additional operation lock. External apps that write directly to MySQL must remain idle during restore. The dump briefly holds a global read lock to get a consistent snapshot.
- Keys and the Windows CLI are accessible to the authorized Windows account; Task Scheduler is a local operator capability, not an unauthenticated web endpoint. The former `backup.php` browser endpoint returns 404.

To repeat verification (creates new backups and retained isolated test databases; leaves the live database unchanged):

```powershell
& 'C:\xampp\php\php.exe' 'C:\xampp\htdocs\tooltrack\tests\backup_workflow.php'
```

See [VERIFICATION.md](VERIFICATION.md) for the completed test results.