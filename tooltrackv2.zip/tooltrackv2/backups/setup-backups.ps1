# Run once as the same Windows user who runs XAMPP and Google Drive for Desktop.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$xamppRoot = Split-Path -Parent (Split-Path -Parent $projectRoot)
$privateRoot = Join-Path $xamppRoot 'tooltrack-private'
New-Item -ItemType Directory -Path $privateRoot -Force | Out-Null
# Keys, SQL working files and history are accessible only to this user, SYSTEM and Administrators.
$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$acl = New-Object System.Security.AccessControl.DirectorySecurity
$acl.SetAccessRuleProtection($true, $false)
foreach ($principal in @($identity, 'S-1-5-18', 'S-1-5-32-544')) {
    if ($principal.StartsWith('S-1-')) { $who = New-Object System.Security.Principal.SecurityIdentifier($principal) } else { $who = New-Object System.Security.Principal.NTAccount($principal) }
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule($who, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
}
Set-Acl -LiteralPath $privateRoot -AclObject $acl
New-Item -ItemType Directory -Path (Join-Path $privateRoot 'work') -Force | Out-Null
& (Join-Path $xamppRoot 'php\php.exe') (Join-Path $projectRoot 'backup.php') initialize
if ($LASTEXITCODE -ne 0) { throw 'Backup initialization failed.' }
Write-Host 'Ready. Open ToolTrack > Settings > Database Backup to configure the synced folder and export your recovery key.'