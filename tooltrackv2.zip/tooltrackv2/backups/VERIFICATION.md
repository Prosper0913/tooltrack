# Backup implementation verification

Verified on 27 October 2026 (Asia/Manila) using XAMPP PHP 8.2.12 and MariaDB 10.4.32.

## Application database round trip

- Source: `tooltrack_db`.
- Tables: **13**.
- Rows across all tables: **577**.
- Encrypted backup: `tooltrack_2026-10-27_09-51-06_7d3f080f8b638376e35cdff830b3196c.ttbackup`.
- Retained verified test database: `tooltrack_restore_test_20261027_025106_dee1cad3`.
- Verified schema character set/collation, table definitions, row counts and extended checksums.
- Confirmed the source manifest remained identical before/after backup, restore and security tests.

## Restore safety test

- Destructive code ran ONLY against newly created fixture database `tooltrack_restore_safety_test_20261027_025107_d581db40`.
- Rejected a staging-manifest mismatch before changing the restore target.
- Verified full restore replaced the disposable fixture data as requested.
- Verified its encrypted safety backup contained the exact pre-restore fixture records.
- Verified maintenance marker was cleared after success.
- Simulated an interrupted restore in the fixture database and successfully recovered its verified safety backup using the explicit-confirmation CLI recovery path.
- Production database remained unchanged throughout.

## Security and failure checks

Passed: anonymous denial; Staff denial; current administrator access; CSRF rejection; authenticated download matching encrypted archive bytes; password-required recovery-key export; GET blocked on the legacy runner; application/CMS maintenance locking; admin controls absent from Staff HTML; wrong recovery key rejected; modified authentication tag rejected; truncated file rejected; plain SQL rejected; htdocs destination rejected; parent traversal rejected; download path traversal rejected.

Protected-folder ACL verified: current Windows user, SYSTEM and Administrators only. Private working directory was empty after completed operations.

Test databases and encrypted backups were retained. No live database restore, automatic deletion, Google account connection, Drive installation or scheduled task was performed.

Run `tests/backup_workflow.php` from the PHP CLI to reproduce these checks. The test creates additional isolated databases and backups; it does not delete them automatically.
## Browser verification

The real administrator panel was opened in a hidden local Chrome session at 1440 x 1000 desktop and 390 x 844 mobile viewports. Both had no horizontal modal overflow, and no uncaught browser errors were recorded. The actual **Backup Now** control was clicked; it reported a successfully saved and verified encrypted backup. Screenshots stayed in the protected private folder, and the temporary authentication session was destroyed after testing.